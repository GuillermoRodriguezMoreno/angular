export interface Producto {
    nombre: string,
    precio: number,
    categoria: string
  }