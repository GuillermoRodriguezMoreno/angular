export interface Usuario {
    id: number,
    nombre: string,
    edad: number,
    profesion: string
  }