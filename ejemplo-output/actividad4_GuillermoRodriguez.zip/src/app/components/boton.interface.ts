export interface Boton {
    id: number,
    texto: string,
    valor: number
}